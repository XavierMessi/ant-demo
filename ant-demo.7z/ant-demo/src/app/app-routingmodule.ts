import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AdminManagerComponent } from "./admin-manager/admin-manager.component";
import { AdminPublishComponent } from "./admin-publish/admin-publish.component";

const routes: Routes = [
  { path: "", pathMatch: "full", redirectTo: "/admin" },
  // { path: 'admin', loadChildren: () => import('./pages/admin-manager/admin-manager.component')
  // .then(m => m.AdminManagerComponent) },
  {
    path: "admin",
    component: AdminManagerComponent,
    children: [{ path: "publish", component: AdminPublishComponent }]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
