import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-admin-manager",
  templateUrl: "./admin-manager.component.html",
  styleUrls: ["./admin-manager.component.css"]
})
export class AdminManagerComponent implements OnInit {
  isCollapsed = false;
  constructor() {}

  ngOnInit() {}
}
